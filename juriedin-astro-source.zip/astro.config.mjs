import { defineConfig } from 'astro/config';
export default defineConfig({
  site: 'https://juriedin.com',
  build: { inlineStylesheets: 'always' },
});
